import React, { useState } from 'react'
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button'
import SIgn_img from './SIgn_img'
import { NavLink } from 'react-router-dom'
import { useNavigate } from 'react-router-dom'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import onAxiosApiCall from '../utils/axios_api';

const Home = () => {

    const history = useNavigate();

    const [inpval, setInpval] = useState({
        name: "",
        email: "",
        username: "",
        password:"",
        phoneNo: "",
        address: "",
        type:""
    })
   
    // get user data
    const getdata = (e) => {
        const { value, name } = e.target;
        setInpval(() => {
            return {
                ...inpval,
                [name]: value
            }
        })

    }

    // Signup 
    const addData = (e) => {
        e.preventDefault();
        const { name, email, username, password, phoneNo, address, type } = inpval;
        if (name === "") {
            toast.error(' name field is requred!',{
                position: "top-center",
            });
        } else if (email === "") {
             toast.error('email field is requred',{
                position: "top-center",
            });
        } else if (!email.includes("@")) {
             toast.error('plz enter valid email addres',{
                position: "top-center",
            });
        } else if (username === "") {
             toast.error('username field is requred',{
                position: "top-center",
            });
        } else if (password === "") {
             toast.error('password field is requred',{
                position: "top-center",
            });
        } else if (password.length < 5) {
             toast.error('password length greater five',{
                position: "top-center",
            });
        } else if (phoneNo === "") {
                toast.error('phone number field is requred',{
                position: "top-center",
            });
        } else if (phoneNo.length > 9) {
            toast.error('Phone number is not valid',{
            position: "top-center",
            });
        }  else if (address === "") {
            toast.error('address field is requred',{
            position: "top-center",
            });
        } else if (type === "") {
            toast.error('user type field is requred',{
            position: "top-center",
            });
        } else {
            onAxiosApiCall(process.env.REACT_APP_API_URL + "api/users/create", "POST", inpval)
            .then((response) => {
                if (response && response !== "") {
                    localStorage.setItem("useryoutube",JSON.stringify(response));
                    toast.success("User signup successfully", {
                        position: "top-center",
                    })
                    setTimeout(() => {
                        history("/");
                    }, 3000)
                };
            })
            .catch((error) => {
                toast.error(error.message, {
                    position: "top-center",
                });
            });
        }

    }

    return (
        <>
            <div className="container mt-3">
                <section className='d-flex justify-content-between'>
                    <div className="left_data mt-3 p-3" style={{ width: "100%" }}>
                        <h3 className='text-center col-lg-6'>Sign Up</h3>
                        <Form >
                            <Form.Group className="mb-3 col-lg-6" controlId="formBasicName">
                                <Form.Control type="text" name='name' onChange={getdata} placeholder="Name" />
                            </Form.Group>
                            <Form.Group className="mb-3 col-lg-6" controlId="formBasicEmail">
                                <Form.Control type="email" name='email' onChange={getdata} placeholder="Email" />
                            </Form.Group>
                            <Form.Group className="mb-3 col-lg-6" controlId="formBasicUsername">
                                <Form.Control type="text" name='username' onChange={getdata} placeholder="Username" />
                            </Form.Group>
                            <Form.Group className="mb-3 col-lg-6" controlId="formBasicPassword">
                                <Form.Control type="password" name='password' onChange={getdata} placeholder="Password" />
                            </Form.Group>
                            <Form.Group className="mb-3 col-lg-6" controlId="formBasicPhonenum">
                                <Form.Control type="text" name='phoneNo' onChange={getdata} placeholder="Phone Number" />
                            </Form.Group>
                            <Form.Group className="mb-3 col-lg-6" controlId="formBasicAddress">
                                <Form.Control as="textarea" name='address' onChange={getdata} placeholder="Address" />
                            </Form.Group>
                            <Form.Group className="mb-3 col-lg-6" controlId="formBasicSelect">
                                <Form.Control
                                as="select"
                                name="type"
                                placeholder='Select User Type'
                                onChange={getdata}
                                >
                                <option value="">Select User Type</option>
                                <option value="A">Admin</option>
                                <option value="U">User</option>
                                </Form.Control>
                            </Form.Group>
                            {/* <Form.Group className="mb-3 col-lg-6" controlId="formBasicEmail">
                                <Form.Control onChange={getdata} name='birthDate' type="date" />
                            </Form.Group> */}
                            <Button variant="primary" className='col-lg-6' onClick={addData} style={{ background: "rgb(67, 185, 127)" }} type="submit">
                                Submit
                            </Button>
                        </Form>
                        <p className='mt-3'>Already Have an Account <span><NavLink to="/">SignIn</NavLink></span> </p>
                    </div>
                    <SIgn_img />
                </section>
                <ToastContainer />
            </div>
        </>
    )
}

export default Home
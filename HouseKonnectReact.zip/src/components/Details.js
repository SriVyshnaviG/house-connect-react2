import React, { useEffect, useState } from 'react'
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button'
import { useNavigate } from 'react-router-dom'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import onAxiosApiCall from '../utils/axios_api';

const Details = () => {
    const [userdata, setUserData] = useState("");
    const [allUser, setAllUsers] = useState([]);
    const history = useNavigate();

    const userlogout = ()=>{
        localStorage.removeItem("user_token");
        localStorage.removeItem("userId");
        history("/");
    }

    useEffect(() => {
        const userId = localStorage.getItem("userId");
        
        onAxiosApiCall(`${process.env.REACT_APP_API_URL}api/users/${userId}`, "GET", "")
        .then((response) => {
            if (response && response !== "") {
                if (response.type == "U") {
                    setUserData(response);
                } else {
                    setUserData(response);
                    getAllUsers();
                }
            } else {
                toast.error(response.error, {
                    position: "top-center",
                });
            };
        })
        .catch((error) => {
            toast.error(error.message, {
                position: "top-center",
            });
        });
    }, [])

    const getAllUsers = () => {
        onAxiosApiCall(`${process.env.REACT_APP_API_URL}api/users`, "GET", "")
        .then((response) => {
            if (Array.isArray(response) && response.length > 0) {
                setAllUsers(response)
            }
        })
        .catch((error) => {
            toast.error(error.message, {
                position: "top-center",
            });
        });
    }

    // Delete user by id
    const deleteUser = (userId) => {
        onAxiosApiCall(`${process.env.REACT_APP_API_URL}api/users/delete/${userId}`, "DELETE", )
        .then((response) => {
            toast.success("User deleted successfully.", {
                position: "top-center",
            });
            setTimeout(() => {
                getAllUsers();
            }, 5000)
        })
        .catch((error) => {
            toast.error(error.message, {
                position: "top-center",
            });
        });
    }

    // Update User
    const updateUser = (userId) => {
        history(`${userId}`);
    }

    return (
        <div className='table-parent-div'>
            <div className='mb-3'>
                <h3>Hello {userdata.name}</h3>
                <Button variant="secondary" onClick={userlogout}>
                    Logout
                </Button>
            </div>  
            <Table striped bordered hover>
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Username</th>
                    <th>Phone Number</th>
                    {userdata.type == "A" && <th>Actions</th>}
                </tr>
            </thead>
            <tbody>
            {userdata.type == "U" ? <tr >
                <td>{userdata.name}</td>
                <td>{userdata.email}</td>
                <td>{userdata.address}</td>
                <td>{userdata.phoneNo}</td>
            </tr> : Array.isArray(allUser) && allUser.length > 0 && allUser.map((user, i) => {
                if (user.id !== userdata.id) {
                    return (
                        <tr key={`user-${i}`}>
                            <td>{user.name}</td>
                            <td>{user.email}</td>
                            <td>{user.address}</td>
                            <td>{user.phoneNo}</td>
                            <td><Button type="button" size="sm" varient="danger" onClick={() => deleteUser(user.id)}>
                                Delete
                            </Button>{' '}
                            <Button type="button" size="sm" varient="danger" onClick={() => updateUser(user.id)}>
                                update
                            </Button></td>
                        </tr>
                    );
                }
            })}
            </tbody>
            </Table>
            <ToastContainer />
      </div>
    )
}

export default Details























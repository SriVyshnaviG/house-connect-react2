import React, { useState } from 'react'
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button'
import SIgn_img from './SIgn_img'
import { useNavigate, NavLink } from 'react-router-dom'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import onAxiosApiCall from '../utils/axios_api';

const Login = () => {

    const history = useNavigate();

    const [inpval, setInpval] = useState({
        username: "",
        password: ""
    })
    
    const getdata = (e) => {
        const { value, name } = e.target;
        setInpval(() => {
            return {
                ...inpval,
                [name]: value
            }
        })

    }

    const addData = (e) => {
        e.preventDefault();
        const { username, password } = inpval;
        if (username === "") {
            toast.error('Username field is requred', {
                position: "top-center",
            });
        } else if (password === "") {
            toast.error('password field is requred', {
                position: "top-center",
            });
        } else if (password.length < 5) {
            toast.error('password length greater five', {
                position: "top-center",
            });
        } else {
            onAxiosApiCall(process.env.REACT_APP_API_URL + "login", "POST", inpval)
            .then((response) => {
                if (response && response.token !== "") {
                    localStorage.setItem("user_token", response.token);
                    localStorage.setItem("userId", response.userId);
                    toast.success("Login successfully", {
                        position: "top-center",
                    })
                    setTimeout(() => {
                        window.location.replace("/details");
                    }, 3000)
                } else {
                    toast.error(response.error, {
                        position: "top-center",
                    });
                };
            })
            .catch((error) => {
                toast.error(error.message, {
                    position: "top-center",
                });
            });
        }

    }

    return (
        <>
            <div className="container mt-3">
                <section className='d-flex justify-content-between'>
                    <div className="left_data mt-3 p-3" style={{ width: "100%" }}>
                        <h3 className='text-center col-lg-6'>Sign IN</h3>
                        <Form >

                            <Form.Group className="mb-3 col-lg-6" controlId="formBasicUsername">

                                <Form.Control type="text" name='username' onChange={getdata} placeholder="Enter Username" />
                            </Form.Group>

                            <Form.Group className="mb-3 col-lg-6" controlId="formBasicPassword">

                                <Form.Control type="password" name='password' onChange={getdata} placeholder="Password" />
                            </Form.Group>
                            <Button variant="primary" className='col-lg-6' onClick={addData} style={{ background: "rgb(67, 185, 127)" }} type="submit">
                                Submit
                            </Button>
                        </Form>
                        <p className='mt-3'>Create new account <span><NavLink to="/signup">Signup</NavLink></span> </p>
                    </div>
                    <SIgn_img />
                </section>
                <ToastContainer />
            </div>
        </>
    )
}

export default Login
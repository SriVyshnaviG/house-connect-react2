import React, { useEffect, useState } from 'react'
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button'
import SIgn_img from './SIgn_img'
import { useNavigate, useParams } from 'react-router-dom'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import onAxiosApiCall from '../utils/axios_api';

const UpdateUser = () => {
    const [inpval, setInpval] = useState({
        name: "",
        email: "",
        //username: "",
        password:"",
        phoneNo: "",
        address: "",
        type:""
    });
    const user = useParams();
    const history = useNavigate();
    useEffect(() => {
        onAxiosApiCall(`${process.env.REACT_APP_API_URL}api/users/${user.id}`, "GET", "")
        .then((response) => {
            if (response && response !== "") {
                setInpval({
                    name: response.name,
                    email: response.email,
                    // username: response.username,
                    password: response.password,
                    phoneNo: response.phoneNo,
                    address: response.address,
                    type: response.type,
                })
            }
        })
        .catch((error) => {
            toast.error(error.message, {
                position: "top-center",
            });
        });
    },[user.id])
   
    // get user data
    const getdata = (e) => {
        const { value, name } = e.target;
        setInpval(() => {
            return {
                ...inpval,
                [name]: value
            }
        })
    }

    const updateData = (e) => {
        e.preventDefault();
        const { name, email, password, phoneNo, address, type } = inpval;
        if (name === "") {
            toast.error(' name field is requred!',{
                position: "top-center",
            });
        } else if (email === "") {
             toast.error('email field is requred',{
                position: "top-center",
            });
        } else if (!email.includes("@")) {
             toast.error('plz enter valid email addres',{
                position: "top-center",
            });
        } else if (password === "") {
             toast.error('password field is requred',{
                position: "top-center",
            });
        } else if (phoneNo === "") {
                toast.error('phone number field is requred',{
                position: "top-center",
            });
        } else if (phoneNo.length > 9) {
            toast.error('Phone number is not valid',{
            position: "top-center",
            });
        } else if (address === "") {
            toast.error('address field is requred',{
            position: "top-center",
            });
        } else if (type === "") {
            toast.error('user type field is requred',{
            position: "top-center",
            });
        } else {
            // update user
            onAxiosApiCall(`${process.env.REACT_APP_API_URL}api/users/${user.id}`, "PUT", inpval)
            .then((response) => {
                if (response && response !== "") {
                    toast.success("User updated successfully.", {
                        position: "top-center",
                    });
                    setTimeout(() => {
                        history("/details");
                    }, 2000)
                };
            })
            .catch((error) => {
                toast.error(error.message, {
                    position: "top-center",
                });
            });
        }

    }

    return (
        <>
            <div className="container mt-3">
                <section className='d-flex justify-content-between'>
                    <div className="left_data mt-3 p-3" style={{ width: "100%" }}>
                        <h3 className='text-center col-lg-6'>Update User</h3>
                        <Form >
                            <Form.Group className="mb-3 col-lg-6" controlId="formBasicName">
                                <Form.Control type="text" name='name' onChange={getdata} placeholder="Name" value={inpval.name} />
                            </Form.Group>
                            <Form.Group className="mb-3 col-lg-6" controlId="formBasicEmail">
                                <Form.Control type="email" name='email' onChange={getdata} placeholder="Email" value={inpval.email} />
                            </Form.Group>
                            {/* <Form.Group className="mb-3 col-lg-6" controlId="formBasicUsername">
                                <Form.Control type="text" name='username' onChange={getdata} placeholder="Username" value={inpval.username}/>
                            </Form.Group> */}
                            {/* <Form.Group className="mb-3 col-lg-6" controlId="formBasicPassword">
                                <Form.Control type="password" name='password' onChange={getdata} placeholder="Password" />
                            </Form.Group> */}
                            <Form.Group className="mb-3 col-lg-6" controlId="formBasicPhonenum">
                                <Form.Control type="text" name='phoneNo' onChange={getdata} placeholder="Phone Number" value={inpval.phoneNo} />
                            </Form.Group>
                            <Form.Group className="mb-3 col-lg-6" controlId="formBasicAddress">
                                <Form.Control as="textarea" name='address' onChange={getdata} placeholder="Address" value={inpval.address}/>
                            </Form.Group>
                            <Form.Group className="mb-3 col-lg-6" controlId="formBasicSelect">
                                <Form.Control
                                as="select"
                                name="type"
                                placeholder='Select User Type'
                                onChange={getdata}
                                value={inpval.type}
                                >
                                <option value="">Select User Type</option>
                                <option value="A">Admin</option>
                                <option value="U">User</option>
                                </Form.Control>
                            </Form.Group>
                            <Button variant="primary" className='col-lg-6' onClick={updateData} style={{ background: "rgb(67, 185, 127)" }} type="submit">
                                Submit
                            </Button>
                        </Form>
                    </div>
                    <SIgn_img />
                </section>
                <ToastContainer />
            </div>
        </>
    )
}

export default UpdateUser
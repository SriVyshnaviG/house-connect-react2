import axios from 'axios';

const onAxiosApiCall = (api_url, method, payload) => {
  const URL = api_url;
  const userToken = localStorage.getItem('user_token');
  let headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
  };
  
  if (userToken !== undefined && userToken !== null && userToken !== "" && api_url !== 'api/users/create') {
    headers.Authorization = `Bearer ${userToken}`;
  }

  return axios(URL, {
    method: method,
    headers: headers,
    data: payload,
  })
    .then(response => response.data)
    .catch(error => {
      throw error;
  });
};

export default onAxiosApiCall;
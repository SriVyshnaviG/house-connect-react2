import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './components/Header';
import Home from './components/Home';
import Login from './components/Login';
import Details from './components/Details';
import UpdateUser from './components/UpdateUser'
import Errror from './components/Errror';
import {Routes,Route} from "react-router-dom"

function App() {
  const userToken = localStorage.getItem('user_token');
  console.log("userToken", userToken);
  return (
  <>
    <Header />
    <Routes>
      <Route path='/' element={<Login />} />
      <Route path='/signup' element={<Home />} />
      {userToken !== undefined && userToken !== null && userToken !== "" &&
      <>
      <Route path='/details' element={<Details />} />
      <Route path='/details/:id' element={<UpdateUser />} />
      </>}
      <Route path='*' element={<Errror />} />
    </Routes>
  </>
  );
}

export default App;
